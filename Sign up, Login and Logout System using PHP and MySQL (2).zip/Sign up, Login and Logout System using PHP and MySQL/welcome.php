<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<?php include 'includes/header.php'; ?>
<h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
<?php include 'includes/footer.php'; ?>
